package com.capgemini.uas.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

public class Users {

	private String loginId;
	private String password;
	
	public Users() {
		super();
	}
		
		
	public Users(String loginId, String password) {
		super();
		this.loginId = loginId;
		this.password = password;
	}
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	
	@Override
	public String toString() {
		return "Users [loginId=" + loginId + ", password=" + password + "]";
	}
	
	
	
	
}
