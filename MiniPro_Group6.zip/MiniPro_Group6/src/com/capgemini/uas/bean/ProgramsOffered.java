package com.capgemini.uas.bean;

import javax.persistence.Entity;

public class ProgramsOffered {

	private String programName;
	private String description;
	private String applicantEligibility;
	private String ceritficate;
	private String university;
	private int duration;
	
	
	
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicantEligibility() {
		return applicantEligibility;
	}
	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}
	public String getCeritficate() {
		return ceritficate;
	}
	public void setCeritficate(String ceritficate) {
		this.ceritficate = ceritficate;
	}
	@Override
	public String toString() {
		return "ProgramsOffered [programName=" + programName + ", description=" + description
				+ ", applicantEligibility=" + applicantEligibility + ", ceritficate=" + ceritficate + ", university="
				+ university + ", duration=" + duration + "]";
	}
	
	
	
	
}
