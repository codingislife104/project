package com.capgemini.uas.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

public class ProgramsScheduled {

	private String scheduledProgramId;
	private String programName;
	private String location;
	private Date startDate;
	private Date endDate;
	private int sessionsPerWeek;
	public String university;
	
	
	public ProgramsScheduled(String schedulePgmId, String programName,
			String location, String university, Date startDate, Date endDate,
			int sessionsPerWeek) {
		super();
		this.scheduledProgramId = schedulePgmId;
		this.programName = programName;
		this.location = location;
		this.university = university;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionsPerWeek = sessionsPerWeek;
	}

	public ProgramsScheduled(String programID, String description,
			String location, Date startDate, Date endDate, int sessions,
			String university) {
		super();
		this.scheduledProgramId = programID;
		this.programName = description;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionsPerWeek = sessions;
		this.university = university;
		
	}
	
	public ProgramsScheduled() {}
	
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public String getScheduledProgramId() {
		return scheduledProgramId;
	}
	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public int
	getSessionsPerWeek() {
		return sessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "ProgramsScheduled [scheduledProgramId=" + scheduledProgramId + ", programName=" + programName
				+ ", location=" + location + ", startDate=" + startDate + ", end_date=" + endDate
				+ ", sessionsPerWeek=" + sessionsPerWeek + ", university=" + university + "]";
	}
	
	
	
	
	
	
	
	
}
