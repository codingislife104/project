package com.capgemini.uas.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

public class Participant {

	private int rollNo;
	private String emailId;
	private int applicationId;
	private String pgmId;
	private String university;
	
	public Participant(int rollNo2, String emailId2, int id, String pgmId2) {
		super();
		this.rollNo = rollNo2;
		this.emailId = emailId2;
		this.applicationId = id;
		this.pgmId = pgmId2;
	}
	
	public Participant() {}
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public String getPgmId() {
		return pgmId;
	}
	public void setPgmId(String pgmId) {
		this.pgmId = pgmId;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	
	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId + ", applicationId=" + applicationId
				+ ", pgmId=" + pgmId + ", university=" + university + "]";
	}
	
	

	
	
}

