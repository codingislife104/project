package com.capgemini.uas.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.capgemini.uas.bean.Applications;
import com.capgemini.uas.bean.Participant;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.Users;
import com.capgemini.uas.exception.UniversityException;

public interface UniversityDao {

	int insertData(Applications bean) throws UniversityException;

	String getProgramId() throws UniversityException;


	ArrayList<Users> allLogin(Users mac) throws UniversityException;

	ArrayList<Users> adminLogin(Users mac) throws UniversityException;

	String getId(String id) throws UniversityException;

	ArrayList<String> retrieveDetails(String university) throws UniversityException;

	ArrayList<Applications> getApplicantList(String programName) throws UniversityException;
	
	int updateStatus(Applications bean) throws UniversityException;

	ArrayList<Applications> retrieveStatus(String pgmName) throws UniversityException;

	int updateCnfStatus(Applications bean) throws UniversityException;

	ArrayList<Applications> getCnfApplicantList(String programName) throws UniversityException;

	ArrayList<ProgramsScheduled> retrievePgms() throws UniversityException;

	ArrayList<Applications> getApplicantStatus(int applicationId) throws UniversityException;

	ArrayList<String> retrievePrograms() throws UniversityException;

	ArrayList<Applications> retrieveAllDetails() throws UniversityException;

	int addProgramOffered(ProgramsOffered pgmbean) throws UniversityException;

	int deleteProgramOffered(String programName) throws UniversityException;

	int updateDetail(ProgramsOffered pgmbean) throws UniversityException;

	int addScheduleProgram(ProgramsScheduled progmbean) throws UniversityException;

	int deleteProgramSchedule(String programSchId) throws UniversityException;

	ArrayList<Applications> getApplicantStatusList(String programName) throws UniversityException;

	ArrayList<String> retrievePgmId() throws UniversityException;

	ArrayList<String> retrievePgmName() throws UniversityException;

	ArrayList<Applications> getApplicantStatList(String programSchId) throws UniversityException;
	
	int insertParticipant(Participant participant) throws UniversityException;

	ArrayList<Participant> retrieveParticipant1() throws UniversityException;

	ArrayList<Applications> retrieveApplicant() throws UniversityException;

	ArrayList<Applications> fetchConfirmedApplicants(int appId) throws UniversityException;
	
}
