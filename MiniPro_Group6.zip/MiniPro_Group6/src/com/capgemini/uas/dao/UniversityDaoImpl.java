package com.capgemini.uas.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.bean.Applications;
import com.capgemini.uas.bean.Participant;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.Users;
import com.capgemini.uas.constants.JdbcConstant;
import com.capgemini.uas.exception.UniversityException;
import com.capgemini.uas.util.DBConnection;


public class UniversityDaoImpl implements UniversityDao{

	ProgramsOffered pgmOfferedbean = new ProgramsOffered();
	Connection conn = null;
	Logger logger = Logger.getRootLogger();
	
	public UniversityDaoImpl() {
		PropertyConfigurator.configure("Log4j.properties");
	}
	
	int result=0;
	
	@Override
	public int insertData(Applications bean) throws UniversityException {
		try {
			conn =DBConnection.getConnection();

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.insertApplicationQuery);
			ps.setString(1, bean.getFullName());
			ps.setDate(2, bean.getDateOfBirth());
			ps.setString(3, bean.getQualification());
			ps.setInt(4, bean.getMarks());
			ps.setString(5, bean.getGoals());
			ps.setString(6, bean.getEmail());
			ps.setString(7, bean.getProgramId());
			ps.setString(8, bean.getStatus());
			ps.setDate(9, bean.getInterviewDate());
			ps.setString(10, bean.getUniversity());

			ps.executeUpdate();
			Statement pst = conn.createStatement();

			ResultSet rs = pst.executeQuery(JdbcConstant.idSelectQuery);

			while (rs.next()) {
				result = rs.getInt(1);
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			// System.out.println("Error Message"+e.getMessage());
			throw new UniversityException(e.getMessage());

		}
		return result;
	}

	@Override
	public String getProgramId() throws UniversityException {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public String getId(String id) throws UniversityException {
		String programId = null;
		// ArrayList list = new ArrayList();
		try {
			conn =DBConnection.getConnection();

			// String
			// sql="select Scheduled_program_id from Programs_Scheduled where Program_Name=?";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.getScheduledProgramID);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			System.out.println("query executed");
			while (rs.next()) {
				System.out.println("in while");
				System.out.println(rs.getString(1));
				programId = rs.getString(1);

			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return programId;
	}

	@Override
	public ArrayList<String> retrieveDetails(String university) throws UniversityException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select * from Programs_Offered where University_name= ? ";
			PreparedStatement pst = conn
					.prepareStatement(JdbcConstant.programsOfferedQuery);

			pst.setString(1, university);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				String programName = rs.getString(1);
				String description = rs.getString(2);
				String eligibility = rs.getString(3);
				Long duration = rs.getLong(4);
				String courseDuration = (duration).toString();
				String degreeCertificate = rs.getString(5);
				list.add("Program Name: " + programName);
				list.add("Description of course: " + description);
				list.add("Eligibility Criteria: " + eligibility);
				list.add("Duration of course(in years): " + courseDuration);
				list.add("Degree certificate: " + degreeCertificate);
				list.add(" ");
			}
			System.out.println(" ");
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public ArrayList<Applications> getApplicantList(String programName) throws UniversityException {
		
		ArrayList<Applications> list = new ArrayList<Applications>();
		
		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select * from Application where status='Applied' AND Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where Program_Name=?)";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.appliedpProgramQuery);

			ps.setString(1, programName);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String fullName = rs.getString(2);
				Date dob = rs.getDate(3);
				String qualification = rs.getString(4);
				int marksObt = rs.getInt(5);
				String goals = rs.getString(6);
				String emailId = rs.getString(7);
				String pgmId = rs.getString(8);
				String status = rs.getString(9);
				Date dateOfInterview = rs.getDate(10);

				list.add(new Applications(id, fullName, dob, qualification,
						marksObt, goals, emailId, pgmId, status,
						dateOfInterview));
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public int updateStatus(Applications bean) throws UniversityException {
		int result = 0;

		try {
			conn = DBConnection.getConnection();
			// String insertQuery=
			// "Update application set status=?,date_of_interview=? where application_id=? ";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.updateApplicationQuery);
			ps.setString(1, bean.getStatus());
			ps.setDate(2, bean.getInterviewDate());

			ps.setInt(3, bean.getApplicationId());

			result = ps.executeUpdate();
			logger.info("Executed successfully");
		}

		catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return result;
	}

	@Override
	public ArrayList<Applications> retrieveStatus(String pgmName) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();
		int id = 0;
		String fullName = null;
		String status = null;

		try {
			conn = DBConnection.getConnection();
			
			PreparedStatement pst = conn
					.prepareStatement(JdbcConstant.acceptedQuery);
			pst.setString(1, pgmName);

			ResultSet rs = pst.executeQuery();

			System.out.println("Query executed");
			while (rs.next()) {
				System.out.println("in while");
				id = rs.getInt(1);

				fullName = rs.getString(2);

				status = rs.getString(9);
				System.out.println(id);

				list.add(new Applications(id, fullName, status));
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public int updateCnfStatus(Applications bean) throws UniversityException {
		int result = 0;

		try {
			conn = DBConnection.getConnection();
			// String insertQuery=
			// "Update application set status=? where application_id=? ";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.updateStatusQuery);
			ps.setString(1, bean.getStatus());
			ps.setInt(2, bean.getApplicationId());

			result = ps.executeUpdate();
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return result;

	}

	@Override
	public ArrayList<Applications> getCnfApplicantList(String programName) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();
		int id = 0;
		String fullName = null;
		String status = null;

		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select Application_id,full_name,status from Application where status NOT LIKE 'Applied' AND Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where Program_Name IN (?))";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.notAppliedQuery);

			ps.setString(1, programName);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				id = rs.getInt(1);
				fullName = rs.getString(2);
				status = rs.getString(3);

				list.add(new Applications(id, fullName, status));
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<ProgramsScheduled> retrievePgms() throws UniversityException {
		ArrayList<ProgramsScheduled> list = new ArrayList<ProgramsScheduled>();
		try {
			conn = DBConnection.getConnection();

			// String sql="select * from Programs_Scheduled ";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.programScheduledQuery);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String programID = rs.getString(1);
				String description = rs.getString(2);
				String location = rs.getString(3);
				Date startDate = rs.getDate(4);
				Date endDate = rs.getDate(5);
				int sessions = rs.getInt(6);
				String university = rs.getString(7);
				list.add(new ProgramsScheduled(programID, description,
						location, startDate, endDate, sessions, university));

			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<Applications> getApplicantStatus(int applicationId) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();
		int id = 0;
		String fullName = null;
		String status = null;

		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select Application_id,full_name,status,Date_Of_Interview from Application where Application_id=?";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.dateofInterviewQuery);

			ps.setInt(1, applicationId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				id = rs.getInt(1);
				fullName = rs.getString(2);
				status = rs.getString(3);
				Date interviewDate = rs.getDate(4);

				list.add(new Applications(id, fullName, status,
						interviewDate));
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<String> retrievePrograms() throws UniversityException {
		ArrayList<String> list = new ArrayList<String>();

		String programName = null;

		try {
			conn = DBConnection.getConnection();

			// String sql="select Program_Name from Programs_Offered";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.programNameQuery);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				programName = rs.getString("program_name");

				list.add(programName);
			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public ArrayList<Applications> retrieveAllDetails() throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();

		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select * from Application where status  LIKE 'Applied' ";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.appliedQuery);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String fullName = rs.getString(2);
				Date dob = rs.getDate(3);
				String qualification = rs.getString(4);
				int marksObt = rs.getInt(5);
				String goals = rs.getString(6);
				String emailId = rs.getString(7);
				String pgmId = rs.getString(8);
				String status = rs.getString(9);
				Date dateOfInterview = rs.getDate(10);

				list.add(new Applications(id, fullName, dob, qualification,
						marksObt, goals, emailId, pgmId, status,
						dateOfInterview));
			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}


	@Override
	public int addProgramOffered(ProgramsOffered pgmbean) throws UniversityException {
		int result = 0;
		try {
			conn = DBConnection.getConnection();
			// String insertQuery=
			// "INSERT INTO Programs_Offered values(?,?,?,?,?,?)";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.insertProgramOffered);
			ps.setString(1, pgmbean.getProgramName());
			ps.setString(2, pgmbean.getDescription());
			ps.setString(3, pgmbean.getApplicantEligibility());
			ps.setInt(4, pgmbean.getDuration());
			ps.setString(5, pgmbean.getCeritficate());
			ps.setString(6, pgmbean.getUniversity());

			result = ps.executeUpdate();
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return result;
	}

	@Override
	public int deleteProgramOffered(String programName1) throws UniversityException {
		Connection conn = null;
		try {

			conn = DBConnection.getConnection();
			// String sql =
			// "delete from Participant where Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where ProgramName=?)";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.deleteParticipantQuery);
			ps.setString(1, programName1);
			ps.executeUpdate();
			// String sql1 =
			// "delete from Application where Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where ProgramName=?)";
			PreparedStatement pst = conn
					.prepareStatement(JdbcConstant.deleteApplicationQuery);
			pst.setString(1, programName1);
			pst.executeUpdate();
			// String sql2 =
			// "delete from Programs_Scheduled where ProgramName=? ";
			PreparedStatement pstr = conn
					.prepareStatement(JdbcConstant.deleteProgramScheduledQuery);
			pstr.setString(1, programName1);
			pstr.executeUpdate();
			// String sql3="delete from Programs_Offered where ProgramName =?";
			PreparedStatement pstrq = conn
					.prepareStatement(JdbcConstant.deleteProgramOfferedQuery);
			pstrq.setString(1, programName1);
			result = pstrq.executeUpdate();

			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return result;
	}

	@Override
	public int updateDetail(ProgramsOffered pgmbean) throws UniversityException {
		int result = 0;

		try {
			conn = DBConnection.getConnection();
			// String insertQuery=
			// "UPDATE Programs_Offered SET description=?,applicant_eligibility  =?,duration = ?,degree_certificate_offer =?, university_name=? where Program_Name=?";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.updateProgramOffered);

			ps.setString(1, pgmbean.getDescription());
			ps.setString(2, pgmbean.getApplicantEligibility());
			ps.setInt(3, pgmbean.getDuration());
			ps.setString(4, pgmbean.getCeritficate());
			ps.setString(5, pgmbean.getUniversity());
			ps.setString(6, pgmbean.getProgramName());

			result = ps.executeUpdate();
			System.out.println(result);
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return result;
	}

	@Override
	public int addScheduleProgram(ProgramsScheduled progmbean) throws UniversityException {
		int result = 0;

		try {
			conn = DBConnection.getConnection();
			// String insertQuery=
			// "insert into Programs_Scheduled values(?,?,?,?,?,?,?)";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.insertProgramScheduledQuery);
			ps.setString(1, progmbean.getScheduledProgramId());
			ps.setString(2, progmbean.getProgramName());
			ps.setString(3, progmbean.getLocation());
			ps.setDate(4, progmbean.getStartDate());
			ps.setDate(5, progmbean.getEndDate());
			ps.setInt(6, progmbean.getSessionsPerWeek());
			ps.setString(7, progmbean.getUniversity());

			result = ps.executeUpdate();
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return result;
	}

	@Override
	public int deleteProgramSchedule(String programSchId) throws UniversityException {
		Connection conn = null;
		int result = 0;
		try {
			conn = DBConnection.getConnection();
			// String sql =
			// "delete from Participant where Scheduled_program_id=?";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.deleteParticipantwithIdQuery);
			ps.setString(1, programSchId);
			ps.executeUpdate();
			// String sql1 =
			// "delete from Application where Scheduled_program_id=?";
			PreparedStatement pst = conn
					.prepareStatement(JdbcConstant.deleteApplicationwithID);
			pst.setString(1, programSchId);
			pst.executeUpdate();
			// String sql2 =
			// "delete from Programs_Scheduled where Scheduled_program_id  = ? ";
			PreparedStatement pstr = conn
					.prepareStatement(JdbcConstant.deleteProgramScheduledwithID);
			pstr.setString(1, programSchId);
			result = pstr.executeUpdate();

			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return result;

	}

	

	@Override
	public ArrayList<String> retrievePgmId() throws UniversityException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn =DBConnection.getConnection();

			// String
			// sql="select Scheduled_program_id  from Programs_Scheduled ";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewScheduledProgramID);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String programID = rs.getString(1);

				list.add(programID);

			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<String> retrievePgmName() throws UniversityException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn =DBConnection.getConnection();

			// String sql="select Program_Name from Programs_Offered ";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewProgramName);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String programName = rs.getString(1);

				list.add(programName);

			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	

	@Override
	public int insertParticipant(Participant participant) throws UniversityException {
		int result = 0;
		try {
			conn = DBConnection.getConnection();

			// String
			// insertQuery="Insert into Participant values(Roll_no_seq.nextval,?,?,?)";
			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.insertParticipantQuery);

			ps.setString(1, participant.getEmailId());
			ps.setInt(2, participant.getApplicationId());
			ps.setString(3, participant.getPgmId());

			result = ps.executeUpdate();
			
			ps=conn.prepareStatement(JdbcConstant.removeQuery);
			ps.setString(1, participant.getEmailId());
			ps.executeUpdate();

			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return result;
	}

	@Override
	public ArrayList<Participant> retrieveParticipant1() throws UniversityException {
		ArrayList<Participant> list = new ArrayList<Participant>();

		try {
			conn = DBConnection.getConnection();

			// String sql="select * from participant order by roll_no";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewParticipant);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int rollNo = rs.getInt(1);
				String emailId = rs.getString(2);
				int id = rs.getInt(3);
				String pgmId = rs.getString(4);
				//String university = rs.getString(5);

				list.add(new Participant(rollNo, emailId, id, pgmId));
			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<Applications> retrieveApplicant() throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();

		try {
			conn =DBConnection.getConnection();

			// String sql="select * from Application where status =?";

			PreparedStatement ps = conn.prepareStatement(JdbcConstant.viewApplicationQuery);
			//ps.setString(1, "confirmed");

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int id = rs.getInt(1);
				String fullName = rs.getString(2);
				Date dob = rs.getDate(3);
				String qualification = rs.getString(4);
				int marksObt = rs.getInt(5);
				String goals = rs.getString(6);
				String emailId = rs.getString(7);
				String pgmId = rs.getString(8);
				String status = rs.getString(9);
				Date dateOfInterview = rs.getDate(10);
				String university = rs.getString(11);

				list.add(new Applications(id, fullName, dob, qualification,
						marksObt, goals, emailId, pgmId, status,
						dateOfInterview, university));
			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public ArrayList<Applications> fetchConfirmedApplicants(int appId) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();

		try {
			conn = DBConnection.getConnection();

			// String sql="select * from Application where application_id =?";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewApplicationwithID);
			ps.setInt(1, appId);

			ResultSet rs = ps.executeQuery();

			rs.next();

			int id = rs.getInt(1);
			String fullName = rs.getString(2);
			Date dob = rs.getDate(3);
			String qualification = rs.getString(4);
			int marksObt = rs.getInt(5);
			String goals = rs.getString(6);
			String emailId = rs.getString(7);
			String pgmId = rs.getString(8);
			String status = rs.getString(9);
			Date dateOfInterview = rs.getDate(10);
			String university = rs.getString(11);

			list.add(new Applications(id, fullName, dob, qualification,
					marksObt, goals, emailId, pgmId, status, dateOfInterview,
					university));

			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		System.out.println(list);
		return list;
	}

	@Override
	public ArrayList<Users> allLogin(Users mac) throws UniversityException {
		String login = null;
		String password = null;
		ArrayList<Users> list = new ArrayList<Users>();
		try {
			conn = DBConnection.getConnection();

			// String sql="select login_id,password from users where role =?";

			// Statement pst=conn.createStatement();
			PreparedStatement pst = conn
					.prepareStatement(JdbcConstant.LoginQuery);
			pst.setString(1, "MAC");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				login = rs.getString("login_id");

				password = rs.getString("password");

				list.add(new Users(login, password));

			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public ArrayList<Users> adminLogin(Users mac) throws UniversityException {
		String login = null;
		String password = null;
		ArrayList<Users> list = new ArrayList<Users>();
		try {
			conn = DBConnection.getConnection();

			// String
			// sql="select login_id,password from users where role IN ('Admin')";
			Statement pst = conn.createStatement();

			ResultSet rs = pst.executeQuery(JdbcConstant.adminQuery);

			while (rs.next()) {

				login = rs.getString(1);

				password = rs.getString(2);

				list.add(new Users(login, password));

			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}

		return list;
	}

	@Override
	public ArrayList<Applications> getApplicantStatusList(String programName) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();

		try {
			conn =DBConnection.getConnection();

			// String
			// sql="select Application_id,status  from Application WHERE Scheduled_program_id =(select Scheduled_program_id from Programs_Scheduled where ProgramName = ?)";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewAppIDandStatus);

			ps.setString(1, programName);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int applicationId = rs.getInt(1);
				String status = rs.getString(2);

				list.add(new Applications(applicationId, status));

			}
			logger.info("Executed successfully");
		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<Applications> getApplicantStatList(String programSchId) throws UniversityException {
		ArrayList<Applications> list = new ArrayList<Applications>();

		try {
			conn =DBConnection.getConnection();

			// String
			// sql="select Application_id,status  from Application WHERE Scheduled_program_id =?";

			PreparedStatement ps = conn
					.prepareStatement(JdbcConstant.viewAppIDfromScheduledPgm);

			ps.setString(1, programSchId);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				int applicationId = rs.getInt(1);
				String status = rs.getString(2);

				list.add(new Applications(applicationId, status));

			}
			logger.info("Executed successfully");

		} catch (IOException | SQLException e) {
			logger.error("Error Message" + e.getMessage());
			throw new UniversityException(e.getMessage());
		}
		return list;
	}

}
