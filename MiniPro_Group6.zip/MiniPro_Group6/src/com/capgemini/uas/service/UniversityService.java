package com.capgemini.uas.service;

import java.sql.Date;
import java.util.ArrayList;

import com.capgemini.uas.bean.Applications;
import com.capgemini.uas.bean.Participant;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.Users;
import com.capgemini.uas.exception.UniversityException;



public interface UniversityService {

	int insertData(Applications bean) throws UniversityException;

	String getProgramId() throws UniversityException;

	boolean checkLogin(Users mac) throws UniversityException;

	boolean checkAdminLogin(Users mac) throws UniversityException;

	String getId(String string) throws UniversityException;

	ArrayList<String> retrieveDetails(String university) throws UniversityException;

	ArrayList<Applications> getApplicantList(String programName) throws UniversityException;

	int updateStatus(Applications bean) throws UniversityException;

	ArrayList<Applications> retrieveStatus(String pgmName) throws UniversityException;

	int updateCnfStatus(Applications bean) throws UniversityException;

	ArrayList<Applications> getCnfApplicantList(String programName) throws UniversityException;

	ArrayList<ProgramsScheduled> retrievePgms() throws UniversityException;

	ArrayList<Applications> getApplicantStatus(int applicationId) throws UniversityException;

	ArrayList<String> retrievePrograms() throws UniversityException;

	ArrayList<Applications> retrieveAllDetails() throws UniversityException;

	boolean validateForm(String qualification);

	int addProgramOffered(ProgramsOffered pgmbean) throws UniversityException;

	int deleteProgramOffered(String programName1) throws UniversityException;

	int updateDetail(ProgramsOffered pgmbean) throws UniversityException;

	int addScheduleProgram(ProgramsScheduled progmbean) throws UniversityException;

	int deleteProgramSchedule(String programSchId) throws UniversityException;

	boolean checkPattern(String firstName);

	boolean validateStatusCheck(ArrayList<Applications> statusCheck);

	ArrayList<String> retrievePgmId() throws UniversityException;

	ArrayList<String> retrievePgmName() throws UniversityException;

	boolean checkRetrieveStatus(ArrayList<Applications> list3);

	boolean checkConfirmList(ArrayList<Applications> cnfList);

	boolean checkAllDetails(ArrayList<Applications> allDetails);

	boolean checkDetails(ArrayList<Applications> allDetails);

	boolean checkprogramSchedule(ArrayList<ProgramsScheduled> programSchedule);

	boolean validateDate(Date d, Date d1, Date d2);

	boolean validateInterviewDate(Date interviewDate, Date d);

	int insertParticipant(Participant participant) throws UniversityException;

	ArrayList<Participant> retrieveParticipant1() throws UniversityException;

	ArrayList<Applications> retrieveApplicant() throws UniversityException;

	ArrayList<Applications> fetchConfirmedApplicants(int appId) throws UniversityException;


}
