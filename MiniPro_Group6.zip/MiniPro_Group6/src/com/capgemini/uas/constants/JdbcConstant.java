package com.capgemini.uas.constants;

public class JdbcConstant {
	
	public static final String idSelectQuery = "select Application_id_seq.currval from Application";

	public static final String insertApplicationQuery = "Insert into Application values(Application_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";

	public static final String LoginQuery = "select login_ID,password from users where role =?";

	public static final String adminQuery = "select login_ID,password from users where role IN ('Admin')";

	public static final String getScheduledProgramID = "select Scheduled_program_id from Programs_Scheduled where Program_Name=?";

	public static final String programsOfferedQuery = "select * from Programs_Offered where University_name= ? ";

	public static final String appliedpProgramQuery = "select * from Application where upper(application.status) like upper('APPLIED') or lower(application.status) like lower('applied') AND Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where Program_Name=?)";

	public static final String updateApplicationQuery = "Update application set status=?,date_of_interview=? where application_id=? ";

	public static final String acceptedQuery = "select * from Application where upper(application.status) like upper('ACCEPTED') or lower(Application.status) like lower('accepted') AND Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where Program_Name=?)";

	public static final String updateStatusQuery = "Update application set status=? where application_id=? ";
	
	public static final String notAppliedQuery="select Application_id,full_name,status from Application where upper(application.status) not like upper('APPLIED') or lower(Application.status) not like lower('applied') AND Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where Program_Name IN (?))";
	
	public static final String programScheduledQuery="select * from Programs_Scheduled";
	
	public static final String dateofInterviewQuery="select Application_id,full_name,status,Date_Of_Interview from Application where Application_id=?";
	
	public static final String programNameQuery="select Program_Name from Programs_Offered";
	
	public static final String appliedQuery="select * from Application where upper(application.status) like upper('APPLIED') or lower(Application.status) like lower('applied')";
	
	public static final	String insertProgramOffered= "INSERT INTO Programs_Offered values(?,?,?,?,?,?)";
	
	public static final String deleteParticipantQuery = "delete from Participant where Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where ProgramName=?)";
	
	public static final String deleteApplicationQuery = "delete from Application where Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where ProgramName=?)";
	
	public static final String deleteProgramScheduledQuery = "delete from Programs_Scheduled where ProgramName=? ";
	
	public static final String deleteProgramOfferedQuery="delete from Programs_Offered where ProgramName =?";
	
	public static final String insertProgramScheduledQuery= "insert into Programs_Scheduled values(?,?,?,?,?,?,?)";
	
	public static final String deleteParticipantwithIdQuery = "delete from Participant where Scheduled_program_id=?";
	
	public static final String deleteApplicationwithID = "delete from Application where Scheduled_program_id=?";
	
	public static final String deleteProgramScheduledwithID = "delete from Programs_Scheduled where Scheduled_program_id  = ? ";
	
	public static final String viewAppIDandStatus="select Application_id,status from Application WHERE Scheduled_program_id =(select Scheduled_program_id from Programs_Scheduled where ProgramName = ?)";
	
	public static final String viewScheduledProgramID="select Scheduled_program_id  from Programs_Scheduled ";
	
	public static final String viewProgramName="select Program_Name from Programs_Offered ";
	
  	public static final String viewAppIDfromScheduledPgm ="select Application_id,status  from Application WHERE Scheduled_program_id =?";
  	
  	public static final String insertParticipantQuery="Insert into Participant values(Roll_no_seq.nextval,?,?,?)";
  	
  	public static final String updateProgramOffered= "UPDATE Programs_Offered SET description=?,applicant_eligibility  =?,duration = ?,degree_certificate_offer =?, university_name=? where Program_Name=?";
  	
  	public static final String viewParticipant="select * from participant order by roll_no";
 
  	public static final String viewApplicationQuery="select * from Application where upper(application.status) like upper('CONFIRMED') or lower(application.status) like lower('confirmed')";
  	
  	public static final String viewApplicationwithID="select * from Application where application_id =?";
  	
  	public static final String removeQuery="delete from application where email_id=?";

}
