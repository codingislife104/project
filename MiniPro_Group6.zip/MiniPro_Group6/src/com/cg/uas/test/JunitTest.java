package com.cg.uas.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.capgemini.uas.bean.Applications;
import com.capgemini.uas.bean.Users;
import com.capgemini.uas.exception.UniversityException;
import com.capgemini.uas.service.UniversityService;
import com.capgemini.uas.service.UniversityServiceImpl;

public class JunitTest {

	UniversityService universityService = new UniversityServiceImpl();

	// Test Case for Admin Login
	@Test
	public void test() throws UniversityException {
		Users login = new Users();
		login.setLoginId("admin");
		login.setPassword("admin");
		assertTrue(universityService.checkAdminLogin(login));
	}

	// Test Case for MAC login
	@Test
	public void test2() throws UniversityException {
		Users login = new Users();
		login.setLoginId("mac");
		login.setPassword("mac");
		assertTrue(universityService.checkLogin(login));
	}

	// Test Case for Apply for Program
	@Test
	public void test3() throws UniversityException {
		Applications apBean = new Applications();
		apBean.setApplicationId(121);
		apBean.setFullName("Shobhita");
		apBean.setQualification("HSC");
		apBean.setMarks(95);
		apBean.setGoals("SC");
		apBean.setEmail("jain@gmail.com");
		apBean.setProgramId("E100");
		apBean.setStatus("confirmed");
		apBean.setUniversity("Himachal");
		int check=universityService.insertData(apBean);
		assertNotEquals(check, 0);
	}

	@Test
	public void test4() throws UniversityException {
		Applications apBean1 = new Applications();
		ArrayList<Applications> arrlist = new ArrayList<Applications>();
		ArrayList<Applications> arrlist1 = new ArrayList<Applications>();
		apBean1.setFullName("Shobhita");
		apBean1.setQualification("HSC");
		apBean1.setMarks(95);
		apBean1.setGoals("SC");
		apBean1.setEmail("jain@gmail.com");
		apBean1.setProgramId("E100");
		apBean1.setStatus("confirmed");
		apBean1.setUniversity("Himachal");
		arrlist1.add(apBean1);
		arrlist = universityService.getApplicantList("EXTC");
		assertEquals(arrlist.toString(), arrlist1.toString());
		}
	
	@Test
	public void test5() {
		//ProgramsScheduledBean psb = new ProgramsScheduledBean();
		
	}

}
