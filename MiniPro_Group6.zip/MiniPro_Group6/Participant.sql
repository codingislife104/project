create table participant(
roll_no varchar2(5) primary key,
email_id varchar2(20),
application_id number,
scheduled_program_id varchar2(5),
constraint application_id_fk foreign key(application_id) references application(application_id),
constraint scheduled_program_id_fk foreign key(scheduled_program_id) references programs_scheduled(scheduled_program_id)
)

alter table participant add university varchar2(30);