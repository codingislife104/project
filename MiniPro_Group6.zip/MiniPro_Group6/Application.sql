create table application(
application_id number primary key,
full_name varchar2(20),
date_of_birth date,
highest_qualification varchar2(10),
marks_obtained number,
goals varchar2(20),
email_id varchar2(20),
scheduled_program_id varchar2(5),
status varchar2(10) default 'applied',
date_of_interview date,
constraint check_status check(status in('accepted','rejected','confirmed'))
)

create sequence application_id_seq
minvalue 1
start with 1
increment by 1;

alter table application add university varchar2(30);
select * from application;