create table users(
login_id varchar2(5) primary key,
password varchar2(10),
role varchar2(5),
constraint check_role check(role in('Admin','MAC'))
)


select * from users

insert into users values('admin','admin','Admin');

insert into users values('mac','mac','MAC');