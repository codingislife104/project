create table location(
locationId varchar2(20) primary key,
city varchar2(20),
state varchar2(20),
zipcode varchar2(10)
)