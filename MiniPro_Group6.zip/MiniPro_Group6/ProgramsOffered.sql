create table programs_offered(
programName varchar2(5),
description varchar2(20),
applicant_eligibility varchar2(40),
duration number,
degree_certificate_offered varchar2(10)
)


alter table programs_offered add university varchar2(30);

