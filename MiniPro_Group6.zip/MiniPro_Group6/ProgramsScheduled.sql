create table programs_scheduled(
scheduled_program_id varchar2(5) primary key,
programname varchar2(5),
location varchar2(10),
start_date date,
end_date date,
constraint location_fk foreign key(location) references Location(locationId),
sessions_per_week number)

alter table programs_scheduled add university varchar2(30);