package com.cg.uas.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.uas.bean.ApplicationBean;
import com.cg.uas.bean.LoginBean;
import com.cg.uas.exception.UniversityException;
import com.cg.uas.service.IUasService;
import com.cg.uas.service.UasServiceImpl;

public class JunitTest {

	IUasService uasService = new UasServiceImpl();

	// Test Case for Admin Login
	@Test
	public void test() throws UniversityException {
		LoginBean login = new LoginBean();
		login.setLoginId("admin");
		login.setPassword("admin");
		assertTrue(uasService.checkAdminLogin(login));
	}

	// Test Case for MAC login
	@Test
	public void test2() throws UniversityException {
		LoginBean login = new LoginBean();
		login.setLoginId("mac");
		login.setPassword("mac");
		assertTrue(uasService.checkLogin(login));
	}

	// Test Case for Apply for Program
	@Test
	public void test3() throws UniversityException {
		ApplicationBean apBean = new ApplicationBean();
		apBean.setApplicationId(121);
		apBean.setFullName("Rishabh Malik");
		apBean.setQualification("HSC");
		apBean.setMarks(95);
		apBean.setGoals("SC");
		apBean.setEmail("rishabh@gmail.com");
		apBean.setProgramId("E100");
		apBean.setStatus("confirmed");
		apBean.setUniversity("Mumbai");
		int check=uasService.insertData(apBean);
		assertNotEquals(check, 0);
	}

	@Test
	public void test4() throws UniversityException {
		ApplicationBean apBean1 = new ApplicationBean();
		ArrayList<ApplicationBean> arrlist = new ArrayList<ApplicationBean>();
		ArrayList<ApplicationBean> arrlist1 = new ArrayList<ApplicationBean>();
		apBean1.setFullName("Rishabh Malik");
		apBean1.setQualification("HSC");
		apBean1.setMarks(95);
		apBean1.setGoals("SC");
		apBean1.setEmail("rishabh@gmail.com");
		apBean1.setProgramId("E100");
		apBean1.setStatus("confirmed");
		apBean1.setUniversity("Mumbai");
		arrlist1.add(apBean1);
		arrlist = uasService.getApplicantList("EXTC");
		assertEquals(arrlist.toString(), arrlist1.toString());
		}
	
	@Test
	public void test5() {
		//ProgramsScheduledBean psb = new ProgramsScheduledBean();
		
	}

}
