package com.cg.uas.exception;

public class UniversityException extends Exception {

	private static final long serialVersionUID = 1L;

	public UniversityException(String message) {
		
		super(message);
	}
}
