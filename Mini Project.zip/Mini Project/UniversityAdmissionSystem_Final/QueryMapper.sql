create table Application(
Application_id number PRIMARY KEY,
Full_Name varchar2(30),
Date_Of_Birth date,
Highest_Qualification varchar2(30),
Marks_Obtained number,
Goals varchar2(20),
Email_Id varchar2(30) UNIQUE,
Scheduled_Program_Id varchar2(5),
Status varchar2(10),
Date_Of_Interview date,
University_name varchar2(30)
);


create table PROGRAMS_OFFERED(
Program_name varchar2(30) primary key,
Description varchar2(30),
Applicant_Eligibility varchar2(40),
Duration number,
Degree_Certificate_Offer varchar2(10),
University_NAME varchar2(30)
);


create table PROGRAMS_SCHEDULED(
Scheduled_Program_Id varchar2(5),
Program_Name varchar2(5),
Location varchar2(10),
Start_Date date,
End_Date date,
Session_Per_Week number(10),
University_NAME varchar2(30)
);


create table PARTICIPANT(
Roll_No varchar2(5),
Email_Id varchar2(20),
Application_id number,
Scheduled_Program_Id varchar2(5)
);


create table USERS(
Login_Id varchar2(5),
Password varchar2(10),
Role varchar2(5)
);

insert into users values('admin','admin','Admin')
insert into users values('mac','mac','MAC')


CREATE SEQUENCE  "APPLICATION_ID_SEQ"  MINVALUE 1000 MAXVALUE 99999999999 INCREMENT BY 1 START WITH 1020 CACHE 20 NOORDER  NOCYCLE ;
CREATE SEQUENCE  "SCHEDULED_PGM_SEQ"  MINVALUE 1200 MAXVALUE 999999999999999 INCREMENT BY 1 START WITH 1200 CACHE 20 NOORDER  NOCYCLE ;
CREATE SEQUENCE  "ROLL_NO_SEQ"  MINVALUE 1234 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 1254 CACHE 20 NOORDER  NOCYCLE ;
   

select * from programs_offered
select * from programs_scheduled
select * from participant
select * from application